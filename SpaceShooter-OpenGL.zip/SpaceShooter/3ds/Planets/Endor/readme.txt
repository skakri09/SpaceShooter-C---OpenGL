SCIFI 3D   www.theforce.net/scifi3d/

Read the AGREEMENT FORM for complete rules on use and 
rules for giving credit with this model.



ENDOR planet

By Dan North (SCIFI 3D staff)


First, this model is absolutely FREE for NON-COMMERCIAL use. 

If you use it for still images or animations, please give my name in the credits for the model.  I spent A LOT of time trying to perfect this model so please give credit where credit is due.  If you use it, please e-mail me, where i can view the image/animation.

If you want to use it commercialy you must first contact Lucasfilm Inc. No commercial reproduction or re-use of these elements permitted without the express written consent of the Artist, Sean Patrick Kennedy and Lucasfilm Inc. 

If you do display any of this material in any kind of non-profit public display, especially web sites, you MUST give written credit to Sean Patrick Kennedy displayed prominently on or directly underneath the material. The association between the artwork and the artists credit must be clearly visible. 

Copyright and Trademarks for Star Wars intellectual property must also be displayed if the artwork in question includes such content. 

All characters, alien creatures, stations, vessel designs, and names from Star Wars, and the films, novels, associated elements and logos, and other licensed works based upon them are copyright Lucasfilm Ltd. Star Wars� 1997 Lucasfilm Ltd.; The Empire Strikes Back� 1980, 1997 Lucasfilm Ltd.; Return of the Jedi� 1983, 1997 Lucasfilm Ltd.