None of the 3ds models here are made by me. I have only done small changes to some of them.
All the models have been downloaded from http://www.scifi3d.com/, and all credits for the 
models goes to the original creators.

For individual credits see the attached readme file inside the spesific model folder. 