#ifndef ProjectileTypes_h__
#define ProjectileTypes_h__

enum ProjectileTypes {SQUARE_FAST_BULLET, SQUARE_SLOW_BULLET};

#endif // ProjectileTypes_h__
