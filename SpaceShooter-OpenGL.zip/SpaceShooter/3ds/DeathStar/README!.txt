
Author Death Star 2 V.1:
Thomas Banner <thomas@spacecadet.dk>
http://banner.3dfrontier.com (3D Studio Max V4.0)

Please visit SCIFI 3D <www.theforce.net/scifi3d/>
for rules governing use, display of credit, and copyright information.


Hi there partener (birdie nam nam)!

I just made this model last night and thought I'd release it right away. I don't know when I'll get time to work more on it so the updates probably won't happen any time soon. The opacity map needs work. I would have fixed it but since I'm nearly all out of space Photoshop complained that scratchdisk was full hence I was limited and couldn't finish it as I would have liked. Anyway..

The model: 

As you can see the DeathStar has a blueish colour and depending on which kind of look you're going for you could make the panels grey by making the bitmap-maps a RGB map and tone the colours grey there, that should do the trick.

Should you want to make a conversion and release it please contact me at: thomas@spacecadet.dk Should you want to host the file somewhere feel free to do so but do contact me before hand. :-)

Disclaimer: 

This model was made for educational purposes and fun. Star Wars and its related trademarks are copyright of Lucasfilm, Twentieth Century Fox. All other trademarks are copyright of their respective owners' copyright. Should you wanna use this model for other than educational purposes contact me at thomas@spacecadet.dk.


On a personal note:

I would really like to see what you make of this model if you use it in a scene so if you have the time please send me some images or animations at: thomas@spacecadet.dk :-)


Enjoy!

Thomas Banner