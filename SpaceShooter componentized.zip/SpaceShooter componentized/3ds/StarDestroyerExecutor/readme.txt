Executor Class Stardestroyer
Fileformat : MAX 3



no texture mapping applied

The original mesh comes from somewhere in the internet, but i lost the original files in a harddiskcrash, so i can't say where it is from.
I remodelled some things, textured the modell and added some lights.
But the model itself is in an alpha stadium. I want to change it, to get such a high detailed version like my stardestroyer.
Zoo asked me for the model and so i give it to him.


Texturing

Sorry that the textures aren't applied, but the texture coordinates were destroyed at export to 3ds.
All maps necessary for texturing are included. If anyone wants to textur it, no problem.
You can mail me at jarjarthomas@gmx.de for help. But i ask you, to return the textured 3ds - file to me, so the rest of world can use it.


LEGAL !! IMPORTANT !!!

First, this modell is absolutely free for NON-COMMERCIAL use. If you want it to use commercial, first contact lucasfilm if the allow it (or they will grab your ... ) and then come to me.

If you use it for stillimages, please give me in the description of the image the credits of the modell. If you make animations please give me the credits in extro.


Thanks

jarjarthomas

JarJarThomas@gmx.de

http://www.novaimages.de


