#ifndef EnemyTypes_H
#define EnemyTypes_H

enum EnemyTypes
{
	IMPERIAL_STAR_DESTROYER,
	IMPERIAL_TIE_FIGHTER,
	IMPERIAL_TIE_INTERCEPTOR,
	IMPERIAL_SHUTTLE
};
#endif // EnemyTypes_H
