#ifndef ProjectileTypes_h__
#define ProjectileTypes_h__

enum ProjectileTypes {LASER_FAST, LASER_SLOW};

#endif // ProjectileTypes_h__
