#ifndef ProjectileTypes_h__
#define ProjectileTypes_h__

enum ProjectileTypes {	LASER_SLOW = 0, 
						LASER_FAST, 
						DOUBLE_LASER,
						TRIPLE_CONE_LASER,
						QUAD_LASER,
						DOUBLE_TRIPLE_CONE_LASER,
						LASER_WALL,
						PLAYER_SEEKING_LASER
					 };

#endif // ProjectileTypes_h__
