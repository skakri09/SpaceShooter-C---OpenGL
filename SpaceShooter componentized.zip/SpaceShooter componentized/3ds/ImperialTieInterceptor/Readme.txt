3DS Mesh ���������������� �����        01 Aug 00

Imperial TIE Interceptor������ �(Featured in the STAR WARS
                                 trilogy by LucasFilm Ltd.)


Manufacturer: Sienar Fleet Systems (SFS)
Weapons: Four SFS L-s9.3 laser cannons
Crew: One pilot
Speed: 125 MGLT, not hyperdrive equipped.
LENGTH: 6.23m


I also plan to build piloted versions (with full interior)
of the TIE Fighter, TIE Interceptor, and the Advanced
TIE with Darth Vader figure.

Faces: 69115
Textures: none
Tools: SoftF/X Pro 4.1, Nugraf 2.2j, Paint Shop Pro 5.

by James R. Bassett
http://www.jrbassett.com/
jim@jrbassett.com
