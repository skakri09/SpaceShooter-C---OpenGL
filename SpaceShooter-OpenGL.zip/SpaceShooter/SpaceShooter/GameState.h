#ifndef GameState_H
#define GameState_H

enum GameState
{
	MAIN_MENU, 
	GAME, 
	QUIT, 
	GAME_OVER, 
	INGAME_MENU,
	NEW_GAME,
	OPTIONS,
	PLAYING_VIDEO
};

#endif // GameState_H
